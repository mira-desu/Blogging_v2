#include <iostream>
#include <fstream>
#include <sstream> // for stringstream
#include <memory>
#include <stdexcept>
#include <limits>
#include <string>

using namespace std;

// Constants for files
const string USERS_FILE = "users.txt";
const string BLOGS_FILE = "blog_posts.txt";

// vector class for dynamic mem
class Vector 
{
public:
    Vector() : elementNum(0), pData(NULL) {}

    Vector(const Vector& theOther) {
        elementNum = theOther.size();
        pData = new string[elementNum];
        for (unsigned int i = 0; i < elementNum; i++) {
            pData[i] = theOther.pData[i];
        }
    }

    ~Vector(){ delete[] pData; } //destructor

    void clear() 
    {
        elementNum = 0;
        delete[] pData;
        pData = NULL;
    }

    void erase(unsigned int position)
     {
        if (position >= elementNum) {
            return;
        }
        string* temp = new string[elementNum - 1];
        for (unsigned int i = 0, j = 0; i < elementNum; i++) {
            if (i != position) {
                temp[j++] = pData[i];
            }
        }
        delete[] pData;
        pData = temp;
        elementNum--;
    }

    string& at(unsigned int position) {
        if (position < elementNum) {
            return pData[position];
        } else {
            throw "Out of bounds!";
        }
    }

    const string& at(unsigned int position) const {
        if (position < elementNum) {
            return pData[position];
        } else {
            throw "Out of bounds!";
        }
    }

    bool insert(unsigned int position, const string& element) {
        if (position <= elementNum) {
            string* temp = new string[elementNum + 1];
            for (unsigned int i = 0; i < position; i++) {
                temp[i] = pData[i];
            }
            temp[position] = element;
            for (unsigned int i = position; i < elementNum; i++) {
                temp[i + 1] = pData[i];
            }
            delete[] pData;
            pData = temp;
            elementNum++;
     } else {
            string* temp = new string[position + 1];
            for (unsigned int i = 0; i < elementNum; i++) {
                temp[i] = pData[i];}
            for (unsigned int i = elementNum; i < position; i++) {
                temp[i] = "";}
         temp[position] = element;
             delete[] pData;
           pData = temp;
            elementNum = position + 1;
        }
        return true;
    }

    const Vector& operator=(const Vector& theOther) {
        if (this != &theOther) {
            delete[] pData;
            elementNum = theOther.size();
            pData = new string[elementNum];
            for (unsigned int i = 0; i < elementNum; i++) {
                pData[i] = theOther.pData[i];
            }
        }
        return *this;
    }

    string& operator[](unsigned int position) {
        return pData[position];
    }

    const string& operator[](unsigned int position) const {
        return pData[position];
    }

    unsigned int size() const {
        return elementNum;
    }

    friend ostream& operator<<(ostream& os, const Vector& v) {
        for (unsigned int i = 0; i < v.size(); i++) {
            os << v.pData[i] << " ";
        }
        os << endl;
        return os;
    }

private:
    unsigned int elementNum;
    string* pData;
};

// post class here everything is public becoz main goal of program is seeing blogs
class Post {
public:
    string date;
    string author;
    string time;
    string keywords;
    string content;

    Post(const string& date, const string& author, const string& time, const string& keywords, const string& content)
        : date(date), author(author), time(time), keywords(keywords), content(content) {}
};

//user class
class User {
protected:
    string name;
    string email;
    string contactInfo;
    string username;
    string password;

public:
    User(const string& name, const string& email, const string& contactInfo, const string& username, const string& password)
        : name(name), email(email), contactInfo(contactInfo), username(username), password(password) {}

    virtual void displayMenu(Vector& posts) = 0;

    string getUsername() const { return username; }
    string getPassword() const { return password; }
    string getName() const { return name; }
    string getEmail() const { return email; }
    string getContactInfo() const { return contactInfo; }
    virtual ~User() {}
};

//blogger class inherited from user
class Blogger : public User {
public:
    Blogger(const string& name, const string& email, const string& contactInfo, const string& username, const string& password)
        : User(name, email, contactInfo, username, password) {}

    void createPost(Vector& posts) {
        string date, time, keywords, content;
         cout << "Enter date (yyyy.mm.dd): ";
       getline(cin, date);
        cout << "Enter time (morning/afternoon/night): ";
      getline(cin, time);
        cout << "Enter keywords: ";
         getline(cin, keywords);
         cout << "Enter content: ";
       getline(cin, content);

     string post = date + "|" + name + "|" + time + "|" + keywords + "|" + content;
        posts.insert(posts.size(), post);
        cout << "Blog post created successfully.\n";
    }

void editPost(Vector& posts) 
   {
        unsigned int index;
        cout << "Enter index of post to edit: ";
        cin >> index;
        cin.ignore();

        if (index >= posts.size()) 
        {  cout << "Invald index.\n";
           return;}

        string post = posts.at(index);
      stringstream ss(post);
        string date, time, keywords, content, author;
       getline(ss, date, '|');
      getline(ss, author, '|');
        getline(ss, time, '|');
      getline(ss, keywords, '|');
        getline(ss, content, '|');

        string input;

    cout << "Current date: " << date << "enter new date (or press enter to skip): ";
        getline(cin, input);
    if (!input.empty()) date = input;

   cout << "Current time: " << time << "enter new time (or press enter to skip): ";
     getline(cin, input);
      if (!input.empty()) time = input;

        cout << "Current keywords: " << keywords <<"enter new keywords (or press enter to skip): ";
     getline(cin, input);
        if (!input.empty()) keywords = input;

       cout << "Current content: " << content << "enter new content (or press enter to skip): ";
   getline(cin, input);
        if (!input.empty()) content = input;

        post = date + "|" + author + "|" + time + "|" + keywords + "|" + content;
    posts.at(index) = post;
        cout << "Blog post updated successfully.\n";
    }

    void deletePost(Vector& posts) {
        unsigned int index;
        cout << "Enter index of post to delete: ";
        cin >> index;
        cin.ignore();

        if (index >= posts.size()) {
            cout << "Invalid index.\n";
            return;
        }

        posts.erase(index);
        cout << "Blog post deleted successfully.\n";
    }

    void viewAllPosts(const Vector& posts) {
        for (unsigned int i = 0; i < posts.size(); ++i) {
            string post = posts.at(i);
            stringstream ss(post);
            string date, author, time, keywords, content;
            getline(ss, date, '|');
            getline(ss, author, '|');
            getline(ss, time, '|');
            getline(ss, keywords, '|');
            getline(ss, content, '|');

            cout << "Post " << i << ":\n";
            cout << "Date: " << date << "\n";
            cout << "Author: " << author << "\n";
            cout << "Time: " << time << "\n";
            cout << "Keywords: " << keywords << "\n";
            cout << "Content: " << content << "\n\n";
        }
    }

   void displayMenu(Vector& posts) override {
    int choice;
    do {
        cout<<"Please enter only integer numbers unless u will get error messages okay ^-^"<<endl; 
        cout << "\n-- Blogger Menu --\n";
        cout << "1. Create a blog post\n";
        cout << "2. Edit a blog post\n";
        cout << "3. Delete a blog post\n";
        cout << "4. View all blog posts\n";
        cout << "5. Log out\n";
        cout << "Enter your choice: ";
        
        if (!(cin >> choice)) {
            cerr << "Invalid input. Please enter an integer number.\n";
            cin.clear(); //Clear the error flag
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); //ignore remaining characters
            continue; //prompt again
        }

        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        switch (choice) {
            case 1:
                createPost(posts);
                break;
            case 2:
                editPost(posts);
                break;
            case 3:
                deletePost(posts);
                break;
            case 4:
                viewAllPosts(posts);
                break;
            case 5:
                return;
            default:
                cout << "Invalid choice. Please try again.\n";
                break;
        }
    } while (choice != 5);
}

};

//reader class
class Reader : public User {
public:
 Reader(const string& name, const string& email, const string& contactInfo, const string& username, const string& password)
        : User(name, email, contactInfo, username, password) {}

    void searchPost(const Vector& posts) {
        string keyword;
         cout << "Enter keyword to search: ";
        getline(cin, keyword);

   for (unsigned int i = 0; i < posts.size(); ++i) {
            string post = posts.at(i);
            stringstream ss(post);
            string date, author, time, keywords, content;
            getline(ss, date, '|');
            getline(ss, author, '|');
            getline(ss, time, '|');
            getline(ss, keywords, '|');
            getline(ss, content, '|');

       if (keywords.find(keyword) != string::npos) {
               cout << "Date: " << date <<endl;
                cout << "Author: " << author << endl;
            cout << "Time: " << time <<endl;
             cout << "Keywords: " << keywords << endl;
        cout << "Content: " << content << endl;
            }
        }
    }

   void displayMenu(Vector& posts) override {
    int choice;
    do {
        cout<<"Please enter only integer numbers unless you will get error messages ^-^"<<endl; 
        cout << "\n-- Reader Menu --\n";
        cout << "1. Search a blog post\n";
        cout << "2. Log out\n";
        cout << "Enter your choice: ";
        
        if (!(cin >> choice)) {
            // Handle invalid input
            cerr << "Invalid input. Please enter an integer number.\n";
            cin.clear(); // Clear the error flag
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Ignore remaining characters
            continue; // Prompt again
        }

        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        switch (choice) {
            case 1:
                searchPost(posts);
                break;
            case 2:
                return;
            default:
                cout << "Invalid choice. Please try again.\n";
                break;
        }
    } while (choice != 2);
}

};

//blogSystem class
class BlogSystem {
private:
    Vector users;
    Vector posts;

public:
    void loadUsers() {
        ifstream file(USERS_FILE);
        if (!file.is_open()) {
            ofstream createFile(USERS_FILE);
           createFile.close();
            cout << "Created new users file"<<endl;
            return;
        }

      string name, email, contactInfo, username, password, role;
        while (getline(file, name)) 
        {
          getline(file, email);
        getline(file, contactInfo);
            getline(file, username);
        getline(file, password);
            getline(file, role);
            string user = name + "|" + email + "|" + contactInfo + "|" + username + "|" + password + "|" + role;
            users.insert(users.size(), user);
        }
        file.close();
    }

    void loadPosts() {
        ifstream file(BLOGS_FILE); //here we have not file not yetr and with help of condition check we could crete file for it 
        if (!file.is_open()) {
            ofstream createFile(BLOGS_FILE);
            createFile.close();
            cout << "Created new blog posts file.\n";
            return;
        }

        string date, author, time, keywords, content;
        while (getline(file, date)) {
           getline(file, author);
            getline(file, time);
         getline(file, keywords);
            getline(file, content);
            string post = date + "|" + author + "|" + time + "|" + keywords + "|" + content;
          posts.insert(posts.size(), post);
        }
        file.close();
    }

  void saveUsers()
   {
        ofstream file(USERS_FILE);
        for (unsigned int i = 0; i < users.size(); ++i) {
            string user = users.at(i);
            stringstream ss(user);
            string name, email, contactInfo, username, password, role;
        getline(ss, name, '|');
            getline(ss, email, '|');
       getline(ss, contactInfo, '|');
            getline(ss, username, '|');
        getline(ss, password, '|');
        getline(ss, role, '|');

            file << name << endl;
            file << email << endl;
            file << contactInfo <<endl;
            file << username <<endl;
            file << password <<endl;
            file << role <<endl;
        }
        file.close();
    }

    void savePosts() 
    {
        ofstream file(BLOGS_FILE);
      for (unsigned int i = 0; i < posts.size(); ++i) {
            string post = posts.at(i);
            stringstream ss(post);
            string date, author, time, keywords, content;
        getline(ss, date, '|');
           getline(ss, author, '|');
            getline(ss, time, '|');
         getline(ss, keywords, '|');
            getline(ss, content, '|');

            file << date <<endl;
            file << author <<endl;
            file << time << endl;
            file << keywords << endl;
            file << content << endl;
        }
      file.close();
    }

    void signUp() {
        string name, email, contactInfo, username, password, role;
        
        cout << "Enter your full name: ";
        getline(cin, name);
        cout << "Enter your email address: ";
        getline(cin, email);
        cout << "Enter your contact information: ";
        getline(cin, contactInfo);
        cout << "Enter your username: ";
        getline(cin, username);
        cout << "Enter your password: ";
        getline(cin, password);
        cout << "Are you a Blogger (y/n): ";
        getline(cin, role);

       string userRole = (role == "y" || role == "Y") ? "Blogger" : "Reader";
        string user = name + "|" + email + "|" + contactInfo + "|" + username + "|" + password + "|" + userRole;
        users.insert(users.size(), user);
        saveUsers();
        cout << "Sign up successful.You can log in ^_^";
    }

    void logIn() {
        string username, password;
        
        cout << "Enter your username: ";
        getline(cin, username);
        cout << "Enter your password: ";
        getline(cin, password);

        for (unsigned int i = 0; i < users.size(); ++i) {
            string user = users.at(i);
            stringstream ss(user);
            string name, email, contactInfo, storedUsername, storedPassword, role;
            getline(ss, name, '|');
            getline(ss, email, '|');
            getline(ss, contactInfo, '|');
            getline(ss, storedUsername, '|');
            getline(ss, storedPassword, '|');
            getline(ss, role, '|');

            if (storedUsername == username && storedPassword == password) {
                if (role == "Blogger") {
                    Blogger blogger(name, email, contactInfo, storedUsername, storedPassword);
                    blogger.displayMenu(posts);
                } else {
                    Reader reader(name, email, contactInfo, storedUsername, storedPassword);
                    reader.displayMenu(posts);
                }
                savePosts();
                return;
            }
        }
        cout << "Username or password is incorrect ^_^ Please try again"<<endl;
    }

    void mainMenu() {
    int choice;
    do {
        cout << "Please enter only an integer number, unless you will get an error message ^~^"<<endl;
        cout << "\n-- Main Menu --\n";
        cout << "1. Sign Up\n";
        cout << "2. Log In\n";
        cout << "3. Exit\n";
        cout << "Enter your choice: ";
        // idea from geeks
        try {
            if (!(cin >> choice)) {
                throw runtime_error("Invalid input. Please enter an integer number ^-^ ok");
            }
        } catch (const runtime_error& e) {
            cerr << e.what() << endl;
            cin.clear(); //clear errorr flag
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); //ignore remaining characters
            continue; 
        }

        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        switch (choice) {
            case 1:
                signUp();
                break;
            case 2:
                logIn();
                break;
            case 3:
                cout << "Exiting the program.\n";
                return;
            default:
                cout << "Invalid choice. Please try again.\n";
                break;
        }
    } while (choice != 3);

}
};

int main() {
    try {
        BlogSystem system;
        system.loadUsers();
        system.loadPosts();
        system.mainMenu();
    } catch (const exception& e) {
        cerr << "Error: " << e.what() << endl;
        return 1;
    }
    return 1001;
}
